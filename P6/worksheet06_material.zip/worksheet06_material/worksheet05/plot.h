/**
 * UCP 120/500 - Helper code for practical worksheet 5.
 */

void plot(double** data, int rows, int cols);
